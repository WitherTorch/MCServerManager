﻿Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

Public NotInheritable Class Server
    Public Event Initallised()
    Public Event ServerInfoUpdated()
    Public Event ServerIconUpdated()
    Public Event ServerUpdateStart()
    Public Event ServerUpdating(percent As Integer)
    Public Event ServerUpdateEnd()

    Public ReadOnly Property IsInitallised As Boolean = False
    Public ReadOnly Property ServerPath As String
    Public ReadOnly Property ServerPathName As String
    Public ReadOnly Property ServerVersion As String
    Public ReadOnly Property ServerVersionType As EServerVersionType
    Public ReadOnly Property Server2ndVersion As String
    Public ReadOnly Property ServerType As EServerType
    Public ReadOnly Property ServerIcon As Image = New Bitmap(64, 64)
    Public ReadOnly Property CanUpdate As Boolean
    Public Property ServerTasks As ServerTask()
    Public Property IsRunning As Boolean
        Get
            Return _IsRunning
        End Get
        Set(value As Boolean)
            RaiseEvent ServerInfoUpdated()
            _IsRunning = value
        End Set
    End Property
    Public Property ServerOptions As New Dictionary(Of String, String)
    Public Property BukkitOptions As BukkitOptions
    Public Property SpigotOptions As SpigotOptions
    Public Property ServerPlugins As New List(Of BukkitPlugin)
    Public Property ServerMods As New List(Of ForgeMod)
    Public ReadOnly Property SpongeVersionType As String
    Public ReadOnly Property Server3rdVersion As String
    Private owner As ServerStatus
    Private _IsRunning As Boolean

    Private Sub New()
    End Sub
    Private Sub New(serverPath As String)
        _ServerPath = serverPath
        owner = Nothing
    End Sub
    Private Sub New(serverPath As String, owner As ServerStatus)
        _ServerPath = serverPath
        Me.owner = owner
    End Sub
    Public Enum EServerType
        [Error]
        Java
        Bedrock
    End Enum
    Public Enum EServerVersionType
        [Error]
        Vanilla
        Forge
        Spigot
        CraftBukkit
        SpongeVanilla
        Nukkit
    End Enum
    Friend Shared Function CreateServer() As Server
        Return New Server
    End Function
    Friend Overloads Shared Function GetServer(serverPath As String, owner As ServerStatus) As Server
        Dim ForgeUpdateCheck As Boolean = True
        If serverPath <> "" Then
            Dim server As New Server(serverPath, owner)
            Try
                Dim taskList As New List(Of ServerTask)
                If My.Computer.FileSystem.FileExists(IO.Path.Combine(serverPath, "server.info")) Then
                    Using reader As New IO.StreamReader(New IO.FileStream(IO.Path.Combine(serverPath, "server.info"), IO.FileMode.Open, IO.FileAccess.Read), System.Text.Encoding.UTF8)
                        Do Until reader.EndOfStream
                            Dim infoText As String = reader.ReadLine
                            Dim info = infoText.Split("=", 2, StringSplitOptions.None)
                            Select Case info(0)
                                Case "server-version"
                                    server._ServerVersion = info(1)
                                Case "server-version-type"
                                    Select Case info(1).ToLower
                                        Case "vanilla"
                                            server._ServerVersionType = EServerVersionType.Vanilla
                                            server._ServerType = EServerType.Java
                                        Case "forge"
                                            server._ServerVersionType = EServerVersionType.Forge
                                            server._ServerType = EServerType.Java
                                        Case "spigot"
                                            server._ServerVersionType = EServerVersionType.Spigot
                                            server._ServerType = EServerType.Java
                                        Case "craftbukkit"
                                            server._ServerVersionType = EServerVersionType.CraftBukkit
                                            server._ServerType = EServerType.Java
                                        Case "nukkit"
                                            server._ServerVersionType = EServerVersionType.Nukkit
                                            server._ServerType = EServerType.Bedrock
                                        Case "spongevanilla"
                                            server._ServerVersionType = EServerVersionType.SpongeVanilla
                                            server._ServerType = EServerType.Java
                                        Case Else
                                            server._ServerVersionType = EServerVersionType.Error
                                            server._ServerType = EServerType.Error
                                    End Select
                                Case "forge-build-version"
                                    server._Server2ndVersion = info(1)
                                Case "nukkit-build-version"
                                    server._Server2ndVersion = info(1)
                                Case "spongeVanilla-version"
                                    server._Server2ndVersion = info(1)
                                Case "spongeVanilla-type"
                                    server._SpongeVersionType = info(1)
                                Case "spongeVanilla-build-version"
                                    server._Server3rdVersion = info(1)
                                Case "tasks"
                                    Dim jsonArray As JArray = JsonConvert.DeserializeObject(Of JArray)(info(1))
                                    For Each jsonObject As JObject In jsonArray
                                        Dim task As New ServerTask(CInt(jsonObject.GetValue("mode")), jsonObject.GetValue("name"))
                                        task.Enabled = jsonObject.GetValue("enabled")
                                        Select Case task.Mode
                                            Case ServerTask.TaskMode.Repeating
                                                task.RepeatingPeriod = jsonObject.GetValue("period")
                                                task.RepeatingPeriodUnit = CInt(jsonObject.GetValue("periodUnit"))
                                            Case ServerTask.TaskMode.Trigger
                                                task.TriggerEvent = CInt(jsonObject.GetValue("event"))
                                        End Select
                                        Dim command As JObject = jsonObject.GetValue("command")
                                        Dim taskCommand As New ServerTask.TaskCommand()
                                        taskCommand.Action = CInt(command.GetValue("action"))
                                        taskCommand.Data = command.GetValue("data")
                                        task.Command = taskCommand
                                        taskList.Add(task)
                                    Next
                            End Select
                        Loop
                    End Using
                End If
                server.ServerTasks = taskList.ToArray
            Catch ex As IO.FileNotFoundException
                server._ServerVersionType = EServerVersionType.Error
                server._ServerType = EServerType.Error
            End Try
            Try
                Dim serverOptions As New Dictionary(Of String, String)
                If My.Computer.FileSystem.FileExists(IO.Path.Combine(serverPath, "server.properties")) Then
                    Using reader As New IO.StreamReader(New IO.FileStream(IO.Path.Combine(serverPath, "server.properties"), IO.FileMode.Open, IO.FileAccess.Read), System.Text.Encoding.UTF8)
                        Dim optionDict As New Dictionary(Of Integer, Boolean)
                        Do Until reader.EndOfStream
                            Try
                                Dim optionText As String = reader.ReadLine
                                If optionText.StartsWith("#") = False Then
                                    Dim options = optionText.Split("=", 2, StringSplitOptions.None)
                                    If options.Count = 2 Then
                                        serverOptions.Add(options(0), options(1))
                                    ElseIf options.Count = 1 Then
                                        If options(0).Trim(" ") <> "" Then serverOptions.Add(options(0), "")
                                    ElseIf options.Count = 0 Then
                                    Else
                                    End If
                                End If
                            Catch ex As Exception
                                Continue Do
                            End Try
                        Loop
                    End Using
                Else
                    Return Nothing
                        Exit Function
                    End If
                If server.ServerVersionType = EServerVersionType.Spigot OrElse server.ServerVersionType = EServerVersionType.CraftBukkit Then
                    If IO.File.Exists(IO.Path.Combine(server.ServerPath, "bukkit.yml")) Then
                        server.BukkitOptions = BukkitOptions.LoadOptions(IO.Path.Combine(server.ServerPath, "bukkit.yml"))
                    Else
                        server.BukkitOptions = BukkitOptions.CreateOptionsWithDefaultSetting(IO.Path.Combine(server.ServerPath, "bukkit.yml"))
                    End If
                End If
                If server.ServerVersionType = EServerVersionType.Spigot Then
                    If IO.File.Exists(IO.Path.Combine(server.ServerPath, "spigot.yml")) Then
                        server.SpigotOptions = SpigotOptions.LoadOptions(IO.Path.Combine(server.ServerPath, "spigot.yml"))
                    Else
                        server.SpigotOptions = SpigotOptions.CreateOptionsWithDefaultSetting(IO.Path.Combine(server.ServerPath, "spigot.yml"))
                    End If
                End If
                server._ServerOptions = serverOptions
            Catch fileException As IO.FileNotFoundException
                Return Nothing
                Exit Function
            End Try
            If My.Computer.FileSystem.FileExists(IO.Path.Combine(serverPath, "server-icon.png")) Then
                server._ServerIcon = Image.FromFile(IO.Path.Combine(serverPath, "server-icon.png"))
            Else
                server._ServerIcon = My.Resources.ServerDefaultIcon
            End If
            server._ServerPathName = (New IO.DirectoryInfo(serverPath)).Name
            Return server
        Else
            Return Nothing
        End If
    End Function
    Friend Overloads Shared Function GetServer(serverPath As String) As Server
        Return GetServer(serverPath, Nothing)
    End Function

    Friend Sub ReloadServerIcon()
        If My.Computer.FileSystem.FileExists(IO.Path.Combine(ServerPath, "server-icon.png")) Then
            _ServerIcon = Image.FromFile(IO.Path.Combine(ServerPath, "server-icon.png"))
        Else
            _ServerIcon = My.Resources.ServerDefaultIcon
        End If
        RaiseEvent ServerIconUpdated()
    End Sub
    Friend Sub Initallise()
        If _ServerVersionType = EServerVersionType.Forge And _Server2ndVersion <> "" Then
            _CanUpdate = False
            Dim thread As New Threading.Thread(Sub()
                                                   If ForgeUpdateCheck() = True Then
                                                       _CanUpdate = True
                                                   Else
                                                       _CanUpdate = False
                                                   End If
                                               End Sub)
            thread.Name = "Forge GetUpdate Thread"
            thread.IsBackground = True
            thread.Start()
        End If
        If _ServerVersionType = EServerVersionType.CraftBukkit OrElse _ServerVersionType = EServerVersionType.Spigot Then
            LoadPlugins()
        ElseIf _serverVersiontype = EServerVersionType.Forge Then
            LoadMods()
        ElseIf _serverVersiontype = EServerVersionType.Nukkit Then
            LoadPlugins()
        End If
        RaiseEvent Initallised()
        _IsInitallised = True
    End Sub
    Private Function ForgeUpdateCheck() As Boolean
        Do Until ForgeVersionDict.ContainsKey(New Version(ServerVersion))
        Loop
        Return New Version(Server2ndVersion) < ForgeVersionDict(New Version(ServerVersion)).Last
    End Function
    Sub LoadPlugins()
        ServerPlugins.Clear()
        Dim pluginPath = IO.Path.Combine(ServerPath, "plugins")
        Dim paths As New List(Of String)
        Try
            If IO.Directory.Exists(pluginPath) Then
                If My.Computer.FileSystem.FileExists(IO.Path.Combine(pluginPath, "pluginList.json")) Then
                    Dim reader As New IO.StreamReader(New IO.FileStream(IO.Path.Combine(pluginPath, "pluginList.json"), IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read, 4096, True))
                    Dim jsonArray As Newtonsoft.Json.Linq.JArray = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JArray)(reader.ReadToEnd())
                    If jsonArray IsNot Nothing Then
                        For Each jsonObject As JObject In jsonArray
                            If IO.File.Exists(jsonObject.GetValue("Path").ToString) = False Then
                                Dim item As New BukkitPlugin(jsonObject.GetValue("Name").ToString, jsonObject.GetValue("Path").ToString, jsonObject.GetValue("VersionDate"))
                                paths.Add(jsonObject.GetValue("Path").ToString)
                                ServerPlugins.Add(item)
                            End If
                        Next
                    End If
                End If
                Dim pluginPathInfo As New IO.DirectoryInfo(pluginPath)
                For Each pluginFileInfo In pluginPathInfo.GetFiles("*.jar", IO.SearchOption.TopDirectoryOnly)
                    Dim item As New BukkitPlugin(pluginFileInfo.Name, pluginFileInfo.FullName, pluginFileInfo.CreationTime.ToString)
                    If paths.Contains(item.Path) = False Then
                        ServerPlugins.Add(item)
                    End If
                Next
            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub SavePlugins()
        Dim pluginPath = IO.Path.Combine(ServerPath, "plugins")
        If IO.Directory.Exists(pluginPath) = False Then
            IO.Directory.CreateDirectory(pluginPath)
        End If
        If My.Computer.FileSystem.FileExists(IO.Path.Combine(pluginPath, "pluginList.json")) = False Then
            IO.File.Create(IO.Path.Combine(pluginPath, "pluginList.json"))
        End If
        Try
            Dim writer As New IO.StreamWriter(New IO.FileStream(IO.Path.Combine(pluginPath, "pluginList.json"), IO.FileMode.Truncate, IO.FileAccess.Write, IO.FileShare.Read, 4096, True))
            Dim jsonArray As New Newtonsoft.Json.Linq.JArray()
            For Each plugin In ServerPlugins
                Dim jsonObject As New Newtonsoft.Json.Linq.JObject()
                jsonObject.Add("Name", New Newtonsoft.Json.Linq.JValue(plugin.Name))
                jsonObject.Add("VersionDate", New Newtonsoft.Json.Linq.JValue(plugin.VersionDate))
                jsonObject.Add("Path", New Newtonsoft.Json.Linq.JValue(plugin.Path))
                jsonArray.Add(jsonObject)
            Next
            writer.Write(Newtonsoft.Json.JsonConvert.SerializeObject(jsonArray))
            writer.Flush()
            writer.Close()
        Catch ex As IO.IOException
        End Try
    End Sub
    Sub LoadMods()
        ServerMods.Clear()
        Dim modPath = IO.Path.Combine(ServerPath, "mods")
        Dim paths As New List(Of String)
        Try
            If IO.Directory.Exists(modPath) Then
                If My.Computer.FileSystem.FileExists(IO.Path.Combine(modPath, "modList.json")) Then
                    Dim reader As New IO.StreamReader(New IO.FileStream(IO.Path.Combine(modPath, "modList.json"), IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read, 4096, True))
                    Dim jsonArray As Newtonsoft.Json.Linq.JArray = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Newtonsoft.Json.Linq.JArray)(reader.ReadToEnd())
                    For Each jsonObject As JObject In jsonArray
                        If IO.File.Exists(jsonObject.GetValue("Path").ToString) Then
                            Dim item As New ForgeMod(jsonObject.GetValue("Name").ToString, jsonObject.GetValue("Path").ToString, jsonObject.GetValue("VersionDate"))
                            paths.Add(jsonObject.GetValue("Path").ToString)
                            ServerMods.Add(item)
                        End If
                    Next
                End If
                Dim modPathInfo As New IO.DirectoryInfo(modPath)
                For Each modFileInfo In modPathInfo.GetFiles("*.jar", IO.SearchOption.TopDirectoryOnly)
                    Dim item As New ForgeMod(modFileInfo.Name, modFileInfo.FullName, modFileInfo.CreationTime.ToString)
                    If paths.Contains(item.Path) = False Then
                        ServerMods.Add(item)
                    End If
                Next
            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub SaveMods()
        Dim modPath = IO.Path.Combine(ServerPath, "mods")
        If IO.Directory.Exists(modPath) = False Then
            IO.Directory.CreateDirectory(modPath)
        End If
        If My.Computer.FileSystem.FileExists(IO.Path.Combine(modPath, "modList.json")) = False Then
            IO.File.Create(IO.Path.Combine(modPath, "modList.json"))
        End If
        Try
            Dim writer As New IO.StreamWriter(New IO.FileStream(IO.Path.Combine(modPath, "modList.json"), IO.FileMode.Truncate, IO.FileAccess.Write, IO.FileShare.Read, 4096, True))
            Dim jsonArray As New Newtonsoft.Json.Linq.JArray()
            For Each forgeMod In ServerMods
                Dim jsonObject As New Newtonsoft.Json.Linq.JObject()
                jsonObject.Add("Name", New Newtonsoft.Json.Linq.JValue(forgeMod.Name))
                jsonObject.Add("VersionDate", New Newtonsoft.Json.Linq.JValue(forgeMod.VersionDate))
                jsonObject.Add("Path", New Newtonsoft.Json.Linq.JValue(forgeMod.Path))
                jsonArray.Add(jsonObject)
            Next
            writer.Write(Newtonsoft.Json.JsonConvert.SerializeObject(jsonArray))
            writer.Flush()
            writer.Close()
        Catch ex As IO.IOException
        End Try
    End Sub
    Friend Sub UpdateServer()
        If ServerVersionType = EServerVersionType.Forge Then
            Dim forgeInstaller As New ForgeUtil2(ServerPath)
            Dim newForgeVersion As String = ForgeVersionDict(New Version(ServerVersion)).Last.ToString
            RaiseEvent ServerUpdateStart()
            AddHandler forgeInstaller.ForgeDownloadProgressChanged, Sub(args)
                                                                        RaiseEvent ServerUpdating(args.ProgressPercentage * 0.75)
                                                                    End Sub
            AddHandler forgeInstaller.ForgeDownloadEnd, Sub()
                                                            If forgeInstaller.InstallForge2(ServerVersion, Server2ndVersion, ServerMemoryMin, ServerMemoryMax) = DialogResult.OK Then
                                                                Try
                                                                    RaiseEvent ServerUpdating(90)
                                                                    forgeInstaller.DeleteForgeInstaller(ServerVersion, Server2ndVersion)
                                                                    GenerateServerInfo(newForgeVersion)
                                                                    RaiseEvent ServerUpdateEnd()
                                                                    _Server2ndVersion = newForgeVersion
                                                                    RaiseEvent ServerInfoUpdated()
                                                                    _CanUpdate = False
                                                                Catch ex As Exception
                                                                    'MsgBox(ex.StackTrace,,Application.ProductName)
                                                                End Try
                                                            End If
                                                        End Sub
            forgeInstaller.DownloadForge(ServerVersion, newForgeVersion)
        End If
    End Sub
    Private Overloads Sub GenerateServerInfo()
        GenerateServerInfo(Server2ndVersion)
    End Sub
    Private Overloads Sub GenerateServerInfo(secondVersion As String)
        My.Computer.FileSystem.WriteAllText(IO.Path.Combine(ServerPath, "server.info"), "", False)
        Using writer As New IO.StreamWriter(New IO.FileStream(IO.Path.Combine(ServerPath, "server.info"), IO.FileMode.Truncate, IO.FileAccess.Write), System.Text.Encoding.UTF8)
            writer.WriteLine("server-version=" & ServerVersion)
            writer.WriteLine("server-version-type=" & ServerVersionType.ToString)
            Select Case ServerVersionType
                Case EServerVersionType.Forge
                    writer.WriteLine("forge-build-version=" & secondVersion)
                Case Server.EServerVersionType.SpongeVanilla
                    writer.WriteLine("spongeVanilla-version=" & secondVersion)
                    writer.WriteLine("spongeVanilla-type=" & SpongeVersionType)
                    writer.WriteLine("spongeVanilla-build-version" & Server3rdVersion)
                Case EServerVersionType.Nukkit
                    writer.WriteLine("nukkit-build-version=" & secondVersion)
            End Select
            Dim jsonArray As New JArray
            If IsNothing(ServerTasks) = False Then
                For Each task As ServerTask In ServerTasks
                    Dim jsonObject As New JObject
                    jsonObject.Add("mode", task.Mode)
                    jsonObject.Add("name", task.Name)
                    jsonObject.Add("enabled", task.Enabled)
                    Select Case task.Mode
                        Case ServerTask.TaskMode.Repeating
                            jsonObject.Add("period", task.RepeatingPeriod)
                            jsonObject.Add("periodUnit", task.RepeatingPeriodUnit)
                        Case ServerTask.TaskMode.Trigger
                            jsonObject.Add("event", task.TriggerEvent)
                    End Select
                    Dim command As New JObject
                    Dim taskCommand As ServerTask.TaskCommand = task.Command
                    command.Add("action", taskCommand.Action)
                    command.Add("data", taskCommand.Data)
                    jsonObject.Add("command", command)
                    jsonArray.Add(jsonObject)
                Next
                writer.WriteLine("tasks=" & JsonConvert.SerializeObject(jsonArray))
            Else
                writer.WriteLine("tasks=" & "[]")
            End If
            writer.Flush()
            writer.Close()
        End Using
    End Sub

    Friend Sub SaveServer(Optional SavePluginOrMods As Boolean = True)

        My.Computer.FileSystem.WriteAllText(IO.Path.Combine(ServerPath, "server.properties"), "", False)
            Dim writer As New IO.StreamWriter(New IO.FileStream(IO.Path.Combine(ServerPath, "server.properties"), IO.FileMode.OpenOrCreate, IO.FileAccess.Write), System.Text.Encoding.UTF8)
        writer.WriteLine("# Minecraft server properties")
        writer.WriteLine("#" & Now.ToString("ddd MMM dd HH:mm:ss K yyyy", New System.Globalization.CultureInfo("en-US")))
            For Each [option] In ServerOptions
            writer.WriteLine(String.Format("{0}={1}", [option].Key, [option].Value))
        Next
            writer.WriteLine()
            writer.Flush()
            writer.Close()
            If SavePluginOrMods Then
            If ServerVersionType = EServerVersionType.CraftBukkit Or ServerVersionType = EServerVersionType.Spigot Then
                SavePlugins()
                If BukkitOptions IsNot Nothing Then BukkitOptions.SaveOption()
                If ServerVersionType = EServerVersionType.Spigot Then
                    If SpigotOptions IsNot Nothing Then SpigotOptions.SaveOption()
                End If
            ElseIf ServerVersionType = EServerVersionType.Forge Then
                SaveMods()
            ElseIf ServerVersionType = EServerVersionType.Nukkit Then
                SavePlugins()
            End If
            End If
        GenerateServerInfo()
    End Sub
    Friend Sub SetPath(path As String)
        If My.Computer.FileSystem.DirectoryExists(path) Then
        Else
            My.Computer.FileSystem.CreateDirectory(path)
        End If
        _ServerPath = path
    End Sub
    Friend Sub SetVersion(version As String, Optional secVersion As String = "", Optional thirdVersion As String = "", Optional sp_verType As SpongeVersionType = GlobalModule.SpongeVersionType.None)
        _ServerVersion = version
        _Server2ndVersion = secVersion
        _Server3rdVersion = thirdVersion
        _SpongeVersionType = sp_verType
    End Sub
    Friend Sub SetVersionType(serverType As EServerType, serverVersionType As EServerVersionType)
        _ServerType = serverType
        _ServerVersionType = serverVersionType
    End Sub
    Public Class BukkitPlugin
        Friend ReadOnly Property Name As String
        Friend ReadOnly Property VersionDate As DateTime
        Friend ReadOnly Property Path As String
        Sub New(Name As String, Path As String, VersionDate As Date)
            _Name = Name
            _VersionDate = VersionDate
            _Path = Path
        End Sub
        Public Shared Operator =(plugin1 As BukkitPlugin, plugin2 As BukkitPlugin) As Boolean
            Return plugin1.Path = plugin2.Path
        End Operator
        Public Shared Operator <>(plugin1 As BukkitPlugin, plugin2 As BukkitPlugin) As Boolean
            Return plugin1.Path <> plugin2.Path
        End Operator
    End Class
    Public Class ForgeMod
        Friend ReadOnly Property Name As String
        Friend ReadOnly Property VersionDate As DateTime
        Friend ReadOnly Property Path As String
        Sub New(Name As String, Path As String, VersionDate As Date)
            _Name = Name
            _VersionDate = VersionDate
            _Path = Path
        End Sub
        Public Shared Operator =(plugin1 As ForgeMod, plugin2 As ForgeMod) As Boolean
            Return plugin1.Path = plugin2.Path
        End Operator
        Public Shared Operator <>(plugin1 As ForgeMod, plugin2 As ForgeMod) As Boolean
            Return plugin1.Path <> plugin2.Path
        End Operator
    End Class
End Class
